---
name: Vibrant Solidarity
colors:
  surface: '#f9f9f9'
  surface-dim: '#dadada'
  surface-bright: '#f9f9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f3'
  surface-container: '#eeeeee'
  surface-container-high: '#e8e8e8'
  surface-container-highest: '#e2e2e2'
  on-surface: '#1b1b1b'
  on-surface-variant: '#434750'
  inverse-surface: '#303030'
  inverse-on-surface: '#f1f1f1'
  outline: '#737781'
  outline-variant: '#c3c6d1'
  surface-tint: '#395f98'
  primary: '#002854'
  on-primary: '#ffffff'
  primary-container: '#113e75'
  on-primary-container: '#86aae8'
  inverse-primary: '#a9c7ff'
  secondary: '#006685'
  on-secondary: '#ffffff'
  secondary-container: '#6fd2fe'
  on-secondary-container: '#005975'
  tertiary: '#590008'
  on-tertiary: '#ffffff'
  tertiary-container: '#820312'
  on-tertiary-container: '#ff8680'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d6e3ff'
  primary-fixed-dim: '#a9c7ff'
  on-primary-fixed: '#001b3d'
  on-primary-fixed-variant: '#1d477e'
  secondary-fixed: '#bfe9ff'
  secondary-fixed-dim: '#6fd2fe'
  on-secondary-fixed: '#001f2a'
  on-secondary-fixed-variant: '#004d65'
  tertiary-fixed: '#ffdad7'
  tertiary-fixed-dim: '#ffb3ae'
  on-tertiary-fixed: '#410004'
  on-tertiary-fixed-variant: '#8e101a'
  background: '#f9f9f9'
  on-background: '#1b1b1b'
  surface-variant: '#e2e2e2'
typography:
  display-lg:
    fontFamily: Anybody
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 52px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Anybody
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Anybody
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Anybody
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-bold:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '700'
    lineHeight: 20px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 40px
  gutter: 16px
  margin-mobile: 20px
---

## Brand & Style

This design system is built for a high-energy, mobile-first solidarity sports event. It balances the institutional trust of educational heritage with the raw, kinetic energy of competitive sports. The personality is communal, urgent, and optimistic.

The visual style is **High-Contrast / Bold** with elements of **Modern Brutalism**. It utilizes heavy stroke weights, high-impact typography, and a "sticker" aesthetic that feels tactile and grassroots. The design prioritizes immediate readability and action-oriented layouts to drive engagement in a fast-paced event environment.

## Colors

The palette is derived from the Colégio Água Viva and HAND VIDA identities. 

- **Primary (Deep Blue):** Used for primary navigation, headers, and structural elements to provide a foundation of reliability.
- **Secondary (Bright Cyan):** The "energy" color. Used for primary calls to action, active states, and highlights.
- **Tertiary (Sport Red):** A high-attention accent used sparingly for badges, live status indicators, or critical alerts.
- **Neutral (High-Energy Black/White):** Deep blacks and crisp whites provide the high-contrast framework required for the "HAND VIDA" aesthetic.

## Typography

The typography strategy is built for impact and technical precision.

- **Headlines:** Use **Anybody** (ExtraBold/Black). It is a variable font that feels athletic and modern. Use tight tracking on large headings to mimic sports editorial styles.
- **Body:** **Hanken Grotesk** provides a clean, contemporary feel that ensures readability for schedules and community news.
- **Labels/Data:** **JetBrains Mono** is used for technical data (scores, times, dates) to give a precise, digital "scoreboard" feel.

## Layout & Spacing

The design system follows a **Fluid Grid** model optimized for mobile-first consumption.

- **Mobile (Default):** 4-column grid with 20px outside margins and 16px gutters.
- **Tablet/Desktop:** 12-column grid with a maximum content width of 1200px.
- **Rhythm:** Use an 8px base grid for all padding and margins. Elements should feel tightly packed to maintain a sense of urgency and density, characteristic of sports event apps.

## Elevation & Depth

This system rejects soft shadows in favor of **Bold Borders** and **Tonal Layers**.

- **Depth:** Conveyed through "Hard Shadows" (offset solid fills) or thick 2px black borders.
- **Layers:** Surfaces use a tiered background system (Surface White, Surface Light Gray, Surface Primary Blue).
- **Interactions:** Elements do not "lift" on hover/press; they shift position (translate -2px, -2px) and reveal a solid black shadow underneath to simulate a physical button press.

## Shapes

The shape language is **Soft (0.25rem)**. 

While the overall vibe is aggressive and bold, slight rounding on corners ensures the UI feels accessible and community-friendly rather than purely industrial. 
- Icons should use a consistent 2px stroke weight.
- Use sharp 90-degree angles only for large container sections or decorative "block" elements.

## Components

- **Buttons:** Primary buttons use the Bright Cyan background with a 2px Black border and JetBrains Mono "Label-Bold" text in all-caps.
- **Cards:** White backgrounds with a 2px solid Black border. Use a "Sport Red" or "Deep Blue" corner flag for category identification.
- **Chips/Badges:** Use a solid Black background with White JetBrains Mono text for a "referee" or "official" feel.
- **Input Fields:** Thick 2px borders that change to Bright Cyan on focus. No soft glows; use a solid 4px offset shadow for the focus state.
- **Lists:** High-contrast rows separated by 2px Black dividers. Use "Deep Blue" for primary list text and "Bright Cyan" for interactive icons.
- **Progress Bars:** Use a "Deep Blue" track with a "Bright Cyan" fill to represent fundraising or event progress.